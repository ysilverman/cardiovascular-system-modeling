import numpy as np
import math



"""
Citrculatory system graph
element index - from-vessel
element - array of to-vessels
"""
Graph = np.array([[1], [2], [3], [4], [0]])
N_vessels = len(Graph)



"""
Average normal parameters 
axis_0 - Res, Sq, Ext
axis_1 - vessel number

axis_0 - Res, Sq, Ext
axis_1 - vessel number
axis_2 - [min_patalogy, max_patalogy] 
"""



########### 2 vessel graph ###########

Graph = Graph[[0, 4]]

"""
Average normal parameters 
axis_0 - Res, Sq, Ext
axis_1 - vessel number
"""
avg_normal_params = np.array([[0.25, 0.3],
                              [265, 300], 
                              [0.2, 0.25]])


"""
Average normal parameters 
axis_0 - Res, Sq, Ext
axis_1 - vessel number
"""
full_ranges = np.array([[[0.0005, 0.05], [0.0005, 0.05]],
                        [[200, 400], [100, 300]],
                        [[0, 0.4], [0, 0.3]]])

LIN = 10
full_lins = []
for i, dim in enumerate(full_ranges):
    for j, ves in enumerate(dim):
        full_lins.append(np.linspace(ves[0], ves[1], LIN))
full_lins = np.array(full_lins).reshape((3, len(Graph), LIN))

########################################


"""
Physical Equations
"""
def dV(Q):
    return Q


def dQ(V, Q, R, C, I=0.00003):
    T = 2.1
    return -T * R / I * Q - T**2/ I / C * V
    #return -500*R * math.sqrt(C / I) * Q - 250000*V


def system(main_var, params):
    V, Q = main_var
    R, _, C = params
    
    return np.array([dV(Q), dQ(V, Q, R, C)])



