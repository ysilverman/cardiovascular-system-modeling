import numpy as np
import math
from numpy.linalg import det, inv, svd, norm
from system import full_system, avg_normal_params, Graph



# def error(left, right, 
#           params=avg_normal_params, 
#           ro=1.05,
#           heart_p=5):
#     """
#     1. Mass conservation
#     2. Momentum conservation
#     """
#     Res, Sq, Ext = params
#     left = left.reshape((len(Graph), -1))
#     right = right.reshape((len(Graph), -1))
#     err = []
        
#     for i, ves in enumerate(Graph):
#         V_i = right[i][0]
#         Q_i = right[i][1] 
#         moment_i = Q_i**2 / 2 / Sq[i]**2 + V_i / Ext[i] / ro
        
#         E1, E2 = Q_i, moment_i
        
#         if i == len(Graph) - 1:
#             E2 -= heart_p
        
#         for to in ves:
            
#             V_to = left[to][0]
#             Q_to = left[to][1]
#             moment_to = Q_to**2 / 2 / Sq[to]**2 + V_to / Ext[to] / ro
            
#             # mass
#             E1 -= Q_to
            
#             # momentum
#             E2 -= moment_to
       
    
#         # E1 += 2*int(V_i < 0)
#         err += [E1, E2]
        
#     return np.array(err)



def error(left, right, 
          params=avg_normal_params, 
          ro=1.05,
          heart_p=5):
    """
    1. Mass conservation
    2. Momentum conservation
    """
    Res, Sq, Ext = params
    left = left.reshape((len(Graph), -1))
    right = right.reshape((len(Graph), -1))
    err = []
        
    for i, ves in enumerate(Graph):
        V_i = right[i][0]
        Q_i = right[i][1]
        T_i = math.sqrt(Ext[i] * 0.00003)
        
        moment_i = Q_i**2 / 2 / Sq[i]**2 + V_i / Ext[i] / ro
        
        E1, E2 = Q_i, moment_i
        
        if i == len(Graph) - 1:
            E2 -= heart_p
        
        for to in ves:
            
            V_to = left[to][0]
            Q_to = left[to][1]
            moment_to = Q_to**2 / 2 / Sq[to]**2 + V_to / Ext[to] / ro
            
            # mass
            E1 -= Q_to
            
            # momentum
            E2 -= moment_to
       
    
        # E1 += 2*int(V_i < 0)
        err += [E1, E2]
        
    return np.array(err)


def RK_system(t0, t1, y_init, 
              system = full_system, 
              params = avg_normal_params,
              n = 100):
    """
    y0 = V(t0) = V0, Q(t0) = Q0
    """
    
    y0 = y_init.copy()
    h = (t1 - t0) / n
    
    for i in range(n):
        k1 = system(t0, y0, params)
        k2 = system(t0 + h/2, y0 + k1 * h/2, params)
        k3 = system(t0 + h/2, y0 + k2 * h/2, params)
        k4 = system(t0 + h, y0 + k3 * h, params)
        k = h * (k1 + 2*k2 + 2*k3 + k4) / 6
        
        t0 += h
        y0 += k
        
    return y0



def shoot(t0=0, t1=1, 
          y_init = np.ones(len(Graph)*2),
          system = full_system,
          params = avg_normal_params,
          solver = RK_system,
          error = error,
          eps = 10**(-5),
          delta = 10**(-5),
          debug = False):

    t = (t1 - t0) / 2
    yt = y_init.astype(np.float32)
    
    cnt = 0
    D = np.nan
    J = np.nan
    conv = 0
    while True:
        cnt += 1
        left = solver(t, t0, yt, system, params)
        right = solver(t, t1, yt, system, params)
        err = error(left, right, params)
        print(np.linalg.norm(err))
        
        if (abs(err) < delta).all():
            break
        
        # find the Jacobian and its determinant
        J = np.empty((len(err), len(yt)))

        for i in range(len(yt)):

            yi = yt.copy()
            yi[i] += eps
            left = solver(t, t0, yi, system, params)
            right = solver(t, t1, yi, system, params)
            erri = error(left, right, params)
            
            J[:, i] = (erri - err) / eps
        
        # Critical point
        if (abs(D) < 10**(-10)):
            conv = 1
            break
        
        try:
            D = det(J)
            # Update yt and calculate new error
            yt -= np.dot(np.linalg.inv(J),  err)
        except:
            return J
        
    
        # Iteration limit exceeded
        if cnt == 30:
            yt = np.nan
            J = np.nan
            D = np.nan
            break


    return cnt, conv, yt, np.linalg.norm(yt), J, D, err






#         try:
#             print(f'Error norm: {np.norm(err)}')
#             u, s, vh = np.linalg.svd(J)
#             print(f'Singular vales: {s}')
#         except:
#             pass