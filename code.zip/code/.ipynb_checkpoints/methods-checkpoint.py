import numpy as np
import math
from numpy.linalg import det, inv, svd, norm
from system import system, avg_normal_params, Graph


def error(left, right, params):    
    V10, Q10, V20, Q20 = left 
    V11, Q11, V21, Q21 = right
    C1, C2 = params[2][0], params[2][1]
    S1, S2 = params[1][0], params[1][1]
    v01, v02 = 2650, 3000
    ro = 1
    T1 = 2.1
    T2 = 2.1
#     T1 = params[0][1] * 0.00003
#     T2 = params[1][1] * 0.00003
    
    # Mass conservation
    mass1 = v01*Q10 / T1 - v02*Q21 / T2
    mass2 = v01*Q11 / T1 - v02*Q20 / T2
    
    # Mommentum conservation
    moment1 = (v01*Q10/math.sqrt(2)/T1/S1)**2 + v01*V10/ro/C1 - (v02*Q21/math.sqrt(2)/T2/S2)**2 + v02*V21/ro/C2 + 9
    moment2 = (v01*Q11/math.sqrt(2)/T1/S1)**2 + v01*V11/ro/C1 - (v02*Q20/math.sqrt(2)/T2/S2)**2 + v02*V20/ro/C2
    
    return np.array([mass1, mass2, moment1, moment2])
    
    

def RK_system(t0, t1, 
              y_init,
              params,
              system = system,
              n = 5000):
    """
    y0 = V(t0) = V0, Q(t0) = Q0
    """
    
    y0 = y_init.copy().astype(float)
    #T = math.sqrt(0.00003*params[1])*500
    T = 2.1
    t0 /= T
    t1 /= T
    
    h = (t1 - t0) / n
    #print(t0, t1, h, T)
    
    for i in range(n):
        k1 = system(y0, params)
        k2 = system(y0 + k1 * h/2, params)
        k3 = system(y0 + k2 * h/2, params)
        k4 = system(y0 + k3 * h, params)
        k = h * (k1 + 2*k2 + 2*k3 + k4) / 6
        
        y0 += k
        
#     return np.nan_to_num(y0)
        return y0

def shoot(y_init,
          params,
          system = system,
          solver = RK_system,
          error = error,
          eps = 10**(-4),
          delta = 10**(-5)):

    yt = np.array(y_init).astype(np.float32)
    
    cnt = 0
    D = np.nan
    J = np.nan
    conv = 0
    while True:
        cnt += 1
        y1, y2 = yt[:2], yt[2:]
        left1 = solver(0.5, 0, y1, params[:, 0], system)
        left2 = solver(1.5, 0.8, y2, params[:, 1], system)
        left = np.concatenate([left1, left2])
        
        right1 = solver(0.5, 0.8, y1, params[:, 0], system)
        right2 = solver(1.5, 2.1, y2, params[:, 1], system)
        right = np.concatenate([right1, right2])
        err = error(left, right, params)
        print(err)
        if (abs(err) < delta).all():
#             conv = 1
#             print('Small Error')
        
            break
        
        # find the Jacobian and its determinant
        J = np.empty((len(err), len(yt)))

        for i in range(len(yt)):

            yi = yt.copy()
            yi[i] += eps
            y1, y2 = yi[:2], yi[2:]
            left1 = solver(0.5, 0, y1, params[:, 0], system)
            left2 = solver(1.5, 0.8, y2, params[:, 1], system)
            left = np.concatenate([left1, left2])

            right1 = solver(0.5, 0.8, y1, params[:, 0], system)
            right2 = solver(1.5, 2.1, y2, params[:, 1], system)
            right = np.concatenate([right1, right2])
            erri = error(left, right, params)
            
            print(i, erri)
            J[:, i] = (erri - err) / eps
        
        
        print(J)
        try:
            D = det(J)
#             print(D)
            # Critical point
            if (abs(D) < 10**(-10)):
                conv = 1
                break
                
            # Update yt and calculate new error
            yt -= np.dot(np.linalg.inv(J),  err)
        except:
#             print('Singular', cnt)
            break
        
    
        # Iteration limit exceeded
        if cnt == 30:
            yt = np.nan
            J = np.nan
            D = np.nan
            break


    return cnt, conv, yt, np.linalg.norm(yt), J, D, err






#         try:
#             print(f'Error norm: {np.norm(err)}')
#             u, s, vh = np.linalg.svd(J)
#             print(f'Singular vales: {s}')
#         except:
#             pass